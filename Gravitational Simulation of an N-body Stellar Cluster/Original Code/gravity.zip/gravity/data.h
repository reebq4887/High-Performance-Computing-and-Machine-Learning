/*=========================================================/
/  Data header, PX457 2025 assignment 5.                   /
/                                                          /
/  Original code created by B.Morgan  - November 2025      /
/  (based on previous code by N. Hine)                     /
/=========================================================*/
#ifndef PX457_GRAVITY_DATA_H
#define PX457_GRAVITY_DATA_H

/* Function prototype for function which explodes the initial cluster */
void initialiseCluster(int nStars, double ke_init, double ClusterMass, double BlackHoleMass, double ClusterRadius,
                       double ClusterApogee, double ClusterPerigee, double *mass, double *radius, double *pos,
                       double *vel, double *acc);

/* Function prototype for function which computes drag on spherical objects in the atmosphere */
double dragForce(double size, double speed, double height, double BHRadius);

/* Function prototype for function which gets command line arguments */
/* Parse Command line arguments */
int read_args(int argc, char **argv, int *Nstar, int *Nsteps, double *timestep, double *KE_init, int *seedtime,
              double *ClusterMass, double *ClusterRadius, double *ClusterApogee, double *ClusterPerigee);

#endif

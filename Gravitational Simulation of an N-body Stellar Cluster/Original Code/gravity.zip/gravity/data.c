/*========================================================/
/   PX457 Assignment 5 2025 - Galaxy Dynamics             /
/                                                         /
/                    Utility functions                    /
/                                                         /
/               B. Morgan - December 2025                 /
/               Original code from N.D.M Hine             /
/========================================================*/
#include "data.h"

#include "mt19937ar.h"

#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

const double c = 2.99792458E+08;                                /* Speed of light in m/s  */
const double LightYear = 365.25 * 24 * 60 * 60 * c;             /* Light year in m        */
const double MSun = 1.9891E+30;                                 /* Solar mass in Kg       */
const double RSun = 6.96342E+08;                                /* Solar radius in m      */
const double BigG = 6.67430e-11;                                /* Gravitational constant */
const double StarDensity = 1408;                                /* average density of the sun in kg/m^3 */
const double EscapeRadius = 200000 * LightYear;                 /* Escape radius to no longer track  */
const double SecondsIn1Myear = 1e6 * 365.25 * 24 * 60 * 60;     /* Seconds in 1 million years */
const double LightYearsPer1Myear = LightYear / SecondsIn1Myear; /* Light years in 1 million years (velocity Units)*/
const double KE_units = MSun * LightYearsPer1Myear * LightYearsPer1Myear; /* Units of kinetic energy */
const double Pi = 3.141592653589793238462643383279502884197;
const double inv2Pi = 0.5 / 3.141592653589793238462643383279502884197;
const double Degrees2Pi = 360.0; /* Degrees in 2xPi         */

double dragForce(double size, double speed, double distance, double BHRadius)
{
    /*==================================================================/
    / Function to compute drag on spherical objects due to dust cloud.  /
    /-------------------------------------------------------------------/
    / B. Morgan   - University of Warwick                               /
    / N.D.M. Hine - University of Warwick                               /
    /==================================================================*/

    // Not active:dust cloud is too destabilising without care taken in parameter setting
    const double dust_magnitude = 0.0E-30;
    
    const double dust_decay_scale = 0.5 * LightYear;
    double dust_density = dust_magnitude * exp(-distance / dust_decay_scale);
    double fDrag = 0.25 * dust_density * speed * speed * size * size;
    // printf("fDrag: %e Distance: %e dust_density %e\n", fDrag, distance/LightYear, dust_density);
    return fDrag;
}

void initialiseCluster(int nStars, double KE_init, double ClusterMass, double BlackHoleMass, double ClusterRadius,
                       double ClusterApogee, double ClusterPerigee, double* mass, double* radius, double* pos,
                       double* vel, double* acc)
{
    /*==================================================================/
    / Function to allocatate and populate the mass, radius, position    /
    / and velocity arrays                                               /
    /-------------------------------------------------------------------/
    / B.Morgan    - University of Warwick                               /
    / N.D.M. Hine - University of Warwick                               /
    /==================================================================*/

    /*---------------/
    / Some constants /
    /---------------*/
    const double ClusterT = 1.0 * SecondsIn1Myear; /* Period of Cluster in My */
    const double ClusterOmega = 2 * Pi / ClusterT; /* Angular speed of Cluster in rad s^-1 */
    const double ClusterAngle = 17;                /* Cluster orbit angle to xy plane (arb) */

    int istar;
    double u, v, s;

    /* Initial velocity of the cluster, making some rather arbitrary choices */
    /* about where in the nodal cycle we are, etc.                        */
    const double perigee = ClusterPerigee;
    const double apogee = ClusterApogee;
    printf("# Angular speed of cluster : %12.6e\n", ClusterOmega * SecondsIn1Myear);

    double Vperi = sqrt(2.0 * BlackHoleMass * BigG * apogee / (perigee * (apogee + perigee)));
    double Vclus[3];
    Vclus[0] = 0.0;
    Vclus[1] = Vperi * cos(ClusterAngle * 2.0 * Pi / Degrees2Pi);
    Vclus[2] = Vperi * sin(ClusterAngle * 2.0 * Pi / Degrees2Pi);

    /* Initial position of the cluster relative to the black hole */
    double Rclus[3];
    Rclus[0] = perigee;
    Rclus[1] = 0.0;
    Rclus[2] = 0.0;
    printf("# Cluster at %12.6e, %12.6e, %12.6e\n", Rclus[0] / LightYear, Rclus[1] / LightYear, Rclus[2] / LightYear);

    /*---------------------------------------------------------------------/
    / Special case for a single object                                     /
    /---------------------------------------------------------------------*/
    if (nStars == 1)
    {
        mass[0] = ClusterMass;
        radius[0] = ClusterRadius;

        pos[0] = Rclus[0];
        pos[1] = Rclus[1];
        pos[2] = Rclus[2];
        vel[0] = Vclus[0];
        vel[1] = Vclus[1];
        vel[2] = Vclus[2];
        acc[0] = 0.0;
        acc[1] = 0.0;
        acc[2] = 0.0;

        return;
    }

    /* Average mass and radius of stars */
    double avMass = ClusterMass / (double)nStars;

    /*---------------------------------------------------------------------/
    / Create several stars, preserving the total linear momentum of        /
    / the cluster and with an extra kinetic energy given by KE_init        /
    /---------------------------------------------------------------------*/

    double totMass = 0.0;             /* Sum of star masses */
    double totP[3] = {0.0, 0.0, 0.0}; /* Total star momentum in cluster frame */

    /* Angular velocity of cluster about its own axis */
    double omega[3];
    omega[0] = 0.0;
    omega[1] = ClusterOmega * sin(ClusterAngle * Pi / 180.0);
    omega[2] = ClusterOmega * cos(ClusterAngle * Pi / 180.0);

    for (istar = 0; istar < nStars; istar++)
    {
        int x = 3 * istar + 0;
        int y = 3 * istar + 1;
        int z = 3 * istar + 2;

        /* Choose random radius from centre of cluster */
        double tmpRadius = cbrt(genrand()) * ClusterRadius;

        /* Choose random angles */
        double tmpPhi = genrand() * 2.0 * Pi;
        double tmpTheta = genrand() * Pi;

        /* Assign position of star */
        double tmpX = tmpRadius * sin(tmpTheta) * cos(tmpPhi);
        double tmpY = tmpRadius * sin(tmpTheta) * sin(tmpPhi);
        double tmpZ = tmpRadius * cos(tmpTheta);

        pos[x] = Rclus[0] + tmpX;
        pos[y] = Rclus[1] + tmpY;
        pos[z] = Rclus[2] + tmpZ;

        double rhat[3];
        rhat[0] = tmpX / tmpRadius;
        rhat[1] = tmpY / tmpRadius;
        rhat[2] = tmpZ / tmpRadius;

        /* Assign velocities and speed */
        s = 2.0;
        while (s >= 1.0)
        {
            u = 2.0 * genrand() - 1.0;
            v = 2.0 * genrand() - 1.0;
            s = u * u + v * v;
        }
        s = sqrt(-2.0 * log(s) / s);

        double speed = fabs((u * s + 4.0));
        mass[istar] = fabs((v * s + 4.0) * avMass * 0.25);

        vel[x] = speed * rhat[0] + (tmpY * omega[2] - tmpZ * omega[1]);
        vel[y] = speed * rhat[1] - (tmpX * omega[2] - tmpZ * omega[0]);
        vel[z] = speed * rhat[2] + (tmpX * omega[1] - tmpY * omega[0]);

        totMass += mass[istar];
    }

    /* Rescale masses and compute momentum */
    double massScale = ClusterMass / totMass;
    for (istar = 0; istar < nStars; istar++)
    {
        int x = 3 * istar + 0;
        int y = 3 * istar + 1;
        int z = 3 * istar + 2;

        /* Rescale mass */
        mass[istar] = mass[istar] * massScale;

        /* Compute running total momentum */
        totP[0] += vel[x] * mass[istar];
        totP[1] += vel[y] * mass[istar];
        totP[2] += vel[z] * mass[istar];
    }

    /* Adjust velocities */
    double totKE = 0.0; /* Sum of star KE     */
    for (istar = 0; istar < nStars; istar++)
    {
        int x = 3 * istar + 0;
        int y = 3 * istar + 1;
        int z = 3 * istar + 2;

        vel[x] = vel[x] - totP[0] / ClusterMass;
        vel[y] = vel[y] - totP[1] / ClusterMass;
        vel[z] = vel[z] - totP[2] / ClusterMass;

        /* Compute running kinetic energy input into stars */
        totKE += 0.5 * mass[istar] * (vel[x] * vel[x] + vel[y] * vel[y] + vel[z] * vel[z]);
    }

    /* Correct velocities for initial kinetic energy */
    /* Also set radius and acceleration         */
    if (KE_init <= 0.0)
        KE_init = totKE; /* If no initial KE specified, use total KE */
    double vScale = sqrt(KE_init / totKE);

    printf("# Cluster target KE_init , totKE %12.6e %12.6e\n", KE_init / KE_units, totKE / KE_units);
    for (istar = 0; istar < nStars; istar++)
    {
        int x = 3 * istar + 0;
        int y = 3 * istar + 1;
        int z = 3 * istar + 2;

        vel[x] = vel[x] * vScale + Vclus[0];
        vel[y] = vel[y] * vScale + Vclus[1];
        vel[z] = vel[z] * vScale + Vclus[2];

        acc[x] = 0.0;
        acc[y] = 0.0;
        acc[z] = 0.0;

        /* Compute radius from star mass (not used in this simulation) */
        radius[istar] = cbrt(3.0 * mass[istar] * inv2Pi * 0.5 / StarDensity);
    }

    return;
}

/* Parse Command line arguments */
int read_args(int argc, char** argv, int* Nstar, int* Nsteps, double* timestep, double* KE_init, int* seedtime,
              double* ClusterMass, double* ClusterRadius, double* ClusterApogee, double* ClusterPerigee)
{
    int index;
    int c;
    opterr = 0;

    /* Process all flags found in argc */
    while ((c = getopt(argc, argv, "N:S:D:K:M:A:P:R:th")) != -1)
        switch (c)
        {
        case 'h':
            printf("Usage: %s [options]\n", argv[0]);
            printf("Options:\n");
            printf("  -N <nStars>        Number of stars\n");
            printf("  -S <nSteps>        Number of steps\n");
            printf("  -D <timestep>      Timestep (in Myr)\n");
            printf("  -K <KE_init>       Initial kinetic energy\n");
            printf("  -M <ClusterMass>   Cluster mass (in MSun)\n");
            printf("  -A <Apogee>        Cluster apogee (in Ly)\n");
            printf("  -P <Perigee>       Cluster perigee (in Ly)\n");
            printf("  -R <Radius>        Cluster radius (in Ly)\n");
            printf("  -t                 Use time-based random seed\n");
            printf("  -h                 Show this help message\n");
            exit(0);
            break;
        case 't':
            *seedtime = 1;
            break;
        case 'N':
            *Nstar = atoi(optarg);
            if (*Nstar <= 0)
            {
                opterr = 1;
                fprintf(stderr, "Number of stars argument could not be read: %s\n", optarg);
            }
            break;
        case 'S':
            *Nsteps = atoi(optarg);
            if (*Nsteps <= 0)
            {
                opterr = 1;
                fprintf(stderr, "Number of steps argument could not be read: %s\n", optarg);
            }
            break;
        case 'D':
            *timestep = atof(optarg) * SecondsIn1Myear;
            if (*timestep <= 0)
            {
                opterr = 1;
                fprintf(stderr, "Timestep argument could not be read: %s\n", optarg);
            }
            break;
        case 'K':
            *KE_init = atof(optarg) * MSun * LightYear * LightYear / (SecondsIn1Myear * SecondsIn1Myear);
            break;
        case 'M':
            *ClusterMass = atof(optarg) * MSun;
            if (*ClusterMass <= 0.0)
            {
                opterr = 1;
                fprintf(stderr, "ClusterMass argument could not be read: %s\n", optarg);
            }
            break;
        case 'A':
            *ClusterApogee = atof(optarg) * LightYear;
            if (*ClusterApogee <= 0.0)
            {
                opterr = 1;
                fprintf(stderr, "ClusterApogee argument could not be read: %s\n", optarg);
            }
            break;
        case 'P':
            *ClusterPerigee = atof(optarg) * LightYear;
            if (*ClusterPerigee <= 0.0)
            {
                opterr = 1;
                fprintf(stderr, "ClusterPerigee argument could not be read: %s\n", optarg);
            }
            break;
        case 'R':
            *ClusterRadius = atof(optarg) * LightYear;
            if (*ClusterRadius <= 0.0)
            {
                opterr = 1;
                fprintf(stderr, "ClusterRadius argument could not be read: %s\n", optarg);
            }
            break;
        case '?':
            if ((optopt == 'N') || (optopt == 'S') || (optopt == 'M') || (optopt == 'D') || (optopt == 'K') ||
                (optopt == 'A') || (optopt == 'P') || (optopt == 'R'))
            {
                fprintf(stderr, "Option -%c requires an argument.\n", optopt);
            }
            else if (isprint(optopt))
            {
                fprintf(stderr, "Unknown option `-%c'.\n", optopt);
            }
            else
            {
                fprintf(stderr, "Unknown option character `\\x%x'.\n", optopt);
            }
            return 1;
        default:
            abort();
        }

    /* List unrecognised arguments */
    for (index = optind; index < argc; index++)
        printf("Non-option argument %s\n", argv[index]);

    return opterr;
}
